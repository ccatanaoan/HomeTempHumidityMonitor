# ArduCAM-mini-ESP8266-12E-Camera-Server
Source code designed to work with an ESP8266-12E and an ArduCAM Mini 2MP Camera.

Copy the contents of the /libraries folder into the Arduino Libraries folder.
On a windows computer this is usually "Documents/Arduino/Libraries"

There is a video demonstration of this application here: https://youtu.be/XqfSz1jZ2JA

Source code overview video: https://youtu.be/H7WHN6SKeg4

Contains fixes for "dark" image captures and blocky broken image capture problems.

