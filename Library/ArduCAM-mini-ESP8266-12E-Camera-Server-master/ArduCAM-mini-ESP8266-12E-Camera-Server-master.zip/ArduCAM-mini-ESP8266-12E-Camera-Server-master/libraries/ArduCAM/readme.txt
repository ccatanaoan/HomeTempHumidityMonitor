Delete this file.
